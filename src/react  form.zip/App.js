import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
import { FaEyeSlash, FaLock } from "react-icons/fa";
import{BsPersonFill}from "react-icons/bs"
import { FaEye } from 'react-icons/fa';
import { useForm } from "react-hook-form";
 function App() {


// === validation using hook-form ===
   const { register, handleSubmit, formState: { errors } } = useForm();
   const onSubmit = (data) => {
      console.log(data);
    }

// ===hide and show password ====
const [show,setshow]=useState(false)
const change=()=>{
setshow(!show)


}

  return(
    <div className="container">
        <div className='con'>
           <h2>NOKIA</h2>
              <h3>FACILIVISS</h3>
                 <form onSubmit={handleSubmit(onSubmit)} >
                    <span><BsPersonFill /></span> 
                      <input type={'email'} id='in'placeholder='Email' {...register("email",
                          {
                                required: true,
                                pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                            })} ></input>
                         {errors.email && <p>Please check the Email</p>}      
                          <br></br><br></br>
                       <span><FaLock /></span>
                         <input type={show?'text':'password'}  id='in' placeholder='Password'  {...register("password", { 
                               required: true,
                                })}></input>
                                <label onClick={change}>{show?<FaEye />:<FaEyeSlash /> }</label>
                                  {errors.password && <p>Please check the password</p>}
                                     <br></br>
                                   <h6>Forget Password ?</h6>
                                    <input type={'submit'} value={'submit'} id="btn"></input>                                 
                              </form>
                                </div>
                                  </div>
)
}
export default App
  
